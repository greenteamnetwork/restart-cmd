async function showUpdateInfo(update) {

    console.log(`
================================
Restart CMD Update Available
================================

Current Version:
${CURRENT_VERSION}

New Version:
${update.version}

Release Date:
${update.releaseDate || "Unknown"}

What's New:
`);

    if (update.changes) {

        update.changes.forEach(change => {
            console.log(" + " + change);
        });

    }

    console.log(`
================================
`);
}