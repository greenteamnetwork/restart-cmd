{
  "name": "Restart CMD",
  "package": "@restartgreen/restart-cmd",
  "publisher": "GreenTeam Services",
  "creator": "GreenBoyYT",

  "installVersion": "1.0.0",

  "installLocation": "%APPDATA%\\RestartCMD",

  "update": {
    "enabled": true,
    "provider": "github",
    "repository": "https://github.com/greenteamnetwork/restart-cmd",
    "manifest": "update.json",
    "updatesFolder": "updates",
    "packagePrefix": "updater@",
    "allowDowngrade": false,
    "autoCheck": true,
    "autoInstall": false
  },

  "paths": {
    "addUserPath": true,
    "addSystemPath": false
  },

  "backup": {
    "enabled": true,
    "folder": "%APPDATA%\\RestartCMD\\backup"
  },

  "support": {
    "team": "helpgreenteam@gmail.com",
    "creator": "greenboyyt1@gmail.com"
  }
}