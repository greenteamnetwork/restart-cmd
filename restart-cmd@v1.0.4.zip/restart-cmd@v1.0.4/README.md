# Restart CMD

A Windows command-line utility created by GreenBoyYT.

## Install

```cmd
npm install -g @restartgreen/restart-cmd