const fs = require("fs");
const path = require("path");
const https = require("https");
const os = require("os");

const AdmZip = require("adm-zip");
const semver = require("semver");

const packageJson = require("../package.json");

const CURRENT_VERSION = packageJson.version;

const OWNER = "greenteamnetwork";
const REPO = "restart-cmd";
const BRANCH = "updates";

const INSTALL_DIR = path.resolve(__dirname, "..");



function githubRequest(apiPath) {

    return new Promise((resolve, reject) => {

        https.get(
            {
                hostname: "api.github.com",
                path: apiPath,
                headers: {
                    "User-Agent": "restart-cmd"
                }
            },

            response => {

                let data = "";

                response.on(
                    "data",
                    chunk => data += chunk
                );

                response.on(
                    "end",
                    () => {

                        try {
                            resolve(JSON.parse(data));
                        }

                        catch(error) {
                            reject(error);
                        }

                    }
                );

            }

        ).on(
            "error",
            reject
        );

    });

}



function downloadFile(url, output) {

    return new Promise((resolve, reject) => {

        const file =
        fs.createWriteStream(output);


        https.get(
            url,

            response => {

                response.pipe(file);


                file.on(
                    "finish",
                    () => {

                        file.close(resolve);

                    }
                );

            }

        ).on(
            "error",
            error => {

                if(fs.existsSync(output)) {
                    fs.unlinkSync(output);
                }

                reject(error);

            }
        );

    });

}



function copyFolder(source, destination) {


    if(!fs.existsSync(destination)) {

        fs.mkdirSync(
            destination,
            {
                recursive:true
            }
        );

    }


    for(const item of fs.readdirSync(source)) {


        const from =
        path.join(
            source,
            item
        );


        const to =
        path.join(
            destination,
            item
        );


        if(fs.statSync(from).isDirectory()) {


            copyFolder(
                from,
                to
            );


        }

        else {


            fs.copyFileSync(
                from,
                to
            );


        }

    }

}



function getVersion(filename) {

    const match =
    filename.match(
        /^@(\d+\.\d+\.\d+)update\.zip$/
    );


    if(!match) {

        return null;

    }


    return match[1];

}



function readUpdateInfo(folder) {


    const infoFile =
    path.join(
        folder,
        "update.json"
    );


    if(!fs.existsSync(infoFile)) {

        return null;

    }


    try {

        return JSON.parse(
            fs.readFileSync(
                infoFile,
                "utf8"
            )
        );

    }

    catch {

        return null;

    }

}



function findUpdateFolder(temp, version) {


    for(const item of fs.readdirSync(temp)) {


        const full =
        path.join(
            temp,
            item
        );


        if(
            fs.statSync(full).isDirectory()
        ) {


            if(
                item === `restart-cmd@${version}` ||
                item === `restart-cmd@v${version}`
            ) {

                return full;

            }

        }

    }



    if(
        fs.existsSync(
            path.join(
                temp,
                "package.json"
            )
        )
    ) {

        return temp;

    }



    return null;

}



function updatePackageVersion(version) {


    const packageFile =
    path.join(
        INSTALL_DIR,
        "package.json"
    );


    if(!fs.existsSync(packageFile)) {

        return;

    }


    const pkg =
    JSON.parse(
        fs.readFileSync(
            packageFile,
            "utf8"
        )
    );


    pkg.version = version;


    fs.writeFileSync(
        packageFile,
        JSON.stringify(
            pkg,
            null,
            2
        )
    );

}



function renameInstallFolder(version) {


    const parent =
    path.dirname(INSTALL_DIR);


    const oldName =
    path.basename(INSTALL_DIR);


    const newName =
    `restart-cmd@${version}`;


    if(oldName === newName) {

        return;

    }


    const newPath =
    path.join(
        parent,
        newName
    );


    try {


        fs.renameSync(
            INSTALL_DIR,
            newPath
        );


        console.log(`
Folder renamed:

${oldName}

to

${newName}
`);

    }

    catch(error) {


        console.log(`
Update files installed.

Folder rename skipped:
${error.message}
`);

    }

}



async function installUpdate(zipFile, version) {


    const temp =
    path.join(
        os.tmpdir(),
        "restart-cmd-update"
    );


    if(fs.existsSync(temp)) {

        fs.rmSync(
            temp,
            {
                recursive:true,
                force:true
            }
        );

    }


    fs.mkdirSync(temp);



    console.log(
        "Extracting update..."
    );



    const zip =
    new AdmZip(zipFile);


    zip.extractAllTo(
        temp,
        true
    );



    const updateInfo =
    readUpdateInfo(temp);



    if(updateInfo) {


        console.log(`
What's New:
===========

${updateInfo.title || "Update"}

`);


        if(Array.isArray(updateInfo.changes)) {


            for(const change of updateInfo.changes) {

                console.log(
                    "- " + change
                );

            }

        }

        console.log("");

    }



    const updateFolder =
    findUpdateFolder(
        temp,
        version
    );



    if(!updateFolder) {

        throw new Error(
            "Update folder not found."
        );

    }



    console.log(
        "Installing files..."
    );


    copyFolder(
        updateFolder,
        INSTALL_DIR
    );


    updatePackageVersion(
        version
    );


    console.log(`
Update complete!

restart-cmd@${version}
`);


    renameInstallFolder(
        version
    );

}



module.exports = {


name:"update",


description:
"Update Restart CMD.",



async run() {


console.log(`
Restart CMD Updater
===================
`);


console.log(
`Current:
restart-cmd@${CURRENT_VERSION}
`
);



const files =
await githubRequest(
    `/repos/${OWNER}/${REPO}/contents?ref=${BRANCH}`
);



if(!Array.isArray(files)) {

    console.log(
        "Could not find updates."
    );

    console.log(files);

    return;

}



let updates =
files
.filter(file =>
    file.type === "file"
)
.map(file => {


    const version =
    getVersion(file.name);


    if(!version) {

        return null;

    }


    return {

        version,

        name:file.name,

        url:file.download_url

    };


})
.filter(Boolean);



updates =
updates.filter(update =>
    semver.gt(
        update.version,
        CURRENT_VERSION
    )
);



if(updates.length === 0) {


    console.log(
        "No updates available."
    );


    return;

}



updates.sort(
(a,b)=>
semver.rcompare(
    a.version,
    b.version
)
);



const update =
updates[0];



console.log(`
Update Found:

${update.name}

New Version:
${update.version}
`);



const zipPath =
path.join(
    os.tmpdir(),
    update.name
);



console.log(
"Downloading..."
);


await downloadFile(
    update.url,
    zipPath
);



await installUpdate(
    zipPath,
    update.version
);



if(fs.existsSync(zipPath)) {

    fs.unlinkSync(zipPath);

}


}


};