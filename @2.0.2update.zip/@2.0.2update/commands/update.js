const fs = require("fs");
const path = require("path");
const https = require("https");
const os = require("os");

const AdmZip = require("adm-zip");
const semver = require("semver");

const packageJson = require("../package.json");

const CURRENT_VERSION = packageJson.version;

const OWNER = "greenteamnetwork";
const REPO = "restart-cmd";
const BRANCH = "updates";

const INSTALL_DIR = path.resolve(__dirname, "..");



function githubRequest(apiPath) {

    return new Promise((resolve, reject) => {

        https.get(
            {
                hostname:"api.github.com",
                path:apiPath,
                headers:{
                    "User-Agent":"restart-cmd"
                }
            },

            response => {

                let data = "";

                response.on(
                    "data",
                    chunk => data += chunk
                );


                response.on(
                    "end",
                    () => {

                        resolve(
                            JSON.parse(data)
                        );

                    }
                );

            }

        ).on(
            "error",
            reject
        );

    });

}



function downloadFile(url, output) {

    return new Promise((resolve,reject)=>{


        const file =
        fs.createWriteStream(output);



        https.get(
            url,

            response=>{


                response.pipe(file);


                file.on(
                    "finish",
                    ()=>{

                        file.close(resolve);

                    }
                );


            }

        ).on(
            "error",
            error=>{


                if(fs.existsSync(output)) {

                    fs.unlinkSync(output);

                }


                reject(error);

            }
        );

    });

}



function getVersion(filename) {


    const match =
    filename.match(
        /^@(\d+\.\d+\.\d+)update\.zip$/
    );


    if(!match) {

        return null;

    }


    return match[1];

}



function copyFolder(source,destination) {


    if(!fs.existsSync(destination)) {

        fs.mkdirSync(
            destination,
            {
                recursive:true
            }
        );

    }



    for(const item of fs.readdirSync(source)) {


        const from =
        path.join(
            source,
            item
        );


        const to =
        path.join(
            destination,
            item
        );



        if(
            fs.statSync(from).isDirectory()
        ) {


            copyFolder(
                from,
                to
            );


        }

        else {


            fs.copyFileSync(
                from,
                to
            );

        }

    }

}



function findUpdateFolder(temp,version) {


    function scan(folder) {


        const name =
        path.basename(folder);



        const files =
        fs.readdirSync(folder);



        if(
            name === `restart-cmd@${version}` ||
            name === `restart-cmd@v${version}`
        ) {

            return folder;

        }



        if(
            files.includes("package.json") &&
            (
                files.includes("bin") ||
                files.includes("commands")
            )
        ) {

            return folder;

        }



        for(const item of files) {


            const full =
            path.join(
                folder,
                item
            );


            if(
                fs.statSync(full).isDirectory()
            ) {


                const result =
                scan(full);



                if(result) {

                    return result;

                }

            }

        }



        return null;

    }



    return scan(temp);

}



function updatePackageVersion(version) {


    const file =
    path.join(
        INSTALL_DIR,
        "package.json"
    );



    if(!fs.existsSync(file)) {

        return;

    }



    const pkg =
    JSON.parse(
        fs.readFileSync(
            file,
            "utf8"
        )
    );



    pkg.version = version;



    fs.writeFileSync(
        file,
        JSON.stringify(
            pkg,
            null,
            2
        )
    );

}



async function installUpdate(zipFile,version) {


    const temp =
    path.join(
        os.tmpdir(),
        "restart-cmd-update"
    );



    if(fs.existsSync(temp)) {

        fs.rmSync(
            temp,
            {
                recursive:true,
                force:true
            }
        );

    }



    fs.mkdirSync(temp);



    console.log(
        "Extracting update..."
    );



    const zip =
    new AdmZip(zipFile);



    zip.extractAllTo(
        temp,
        true
    );



    let updateFolder =
    findUpdateFolder(
        temp,
        version
    );



    // final safety fallback
    if(!updateFolder) {

        updateFolder = temp;

    }



    console.log(
        "Installing update..."
    );



    copyFolder(
        updateFolder,
        INSTALL_DIR
    );



    updatePackageVersion(
        version
    );



    console.log(`

Update complete!

restart-cmd@${version}

`);

}



module.exports = {


name:"update",


description:"Update Restart CMD.",



async run(){


console.log(`
Restart CMD Updater
===================
`);



console.log(
`Installed:
restart-cmd@${CURRENT_VERSION}
`
);



const files =
await githubRequest(
    `/repos/${OWNER}/${REPO}/contents?ref=${BRANCH}`
);



if(!Array.isArray(files)) {


    console.log(
        "No update files found."
    );


    console.log(files);

    return;

}



let updates =
files
.filter(
file=>file.type==="file"
)
.map(file=>{


    const version =
    getVersion(file.name);



    if(!version) {

        return null;

    }



    return {

        version,

        name:file.name,

        url:file.download_url

    };


})
.filter(Boolean);



updates =
updates.filter(update=>
    semver.gt(
        update.version,
        CURRENT_VERSION
    )
);



if(updates.length===0) {


    console.log(
        "No updates available."
    );


    return;

}



updates.sort(
(a,b)=>
semver.rcompare(
    a.version,
    b.version
)
);



const update =
updates[0];



console.log(`
Update Found:

${update.name}

Version:
${update.version}
`);



const zipPath =
path.join(
    os.tmpdir(),
    update.name
);



console.log(
"Downloading..."
);



await downloadFile(
    update.url,
    zipPath
);



await installUpdate(
    zipPath,
    update.version
);



if(fs.existsSync(zipPath)) {

    fs.unlinkSync(zipPath);

}


}


};