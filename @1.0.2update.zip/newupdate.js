const fs = require("fs");
const path = require("path");
const semver = require("semver");

const currentVersion =
require("../package.json").version;


const ROOT = __dirname;


console.log("Restart CMD Update Checker");
console.log("==========================");

console.log(
"Current version:",
currentVersion
);


// Find update folders

const folders = fs.readdirSync(ROOT)
.filter(name =>
    name.startsWith("restart-cmd@")
)
.filter(name =>
    fs.statSync(
        path.join(ROOT,name)
    ).isDirectory()
);


// Get versions

const updates = folders.map(folder => {

    const version =
        folder.replace(
            "restart-cmd@",
            ""
        );

    return {
        folder,
        version
    };

})
.filter(update =>
    semver.valid(update.version)
);


// Remove older/same versions

const available =
updates.filter(update =>
    semver.gt(
        update.version,
        currentVersion
    )
);


// No updates

if (available.length === 0) {

    console.log(
        "No updates available."
    );

    process.exit(0);
}


// Sort newest first

available.sort((a,b)=>
    semver.rcompare(
        a.version,
        b.version
    )
);


const newest = available[0];


console.log(`
Update found!

Folder:
${newest.folder}

Version:
${newest.version}
`);


// Check package.json

const packagePath =
path.join(
    ROOT,
    newest.folder,
    "package.json"
);


if (!fs.existsSync(packagePath)) {

    console.error(
        "Update failed: package.json missing"
    );

    process.exit(1);
}


const pkg =
JSON.parse(
    fs.readFileSync(
        packagePath,
        "utf8"
    )
);


if(pkg.version !== newest.version){

    console.error(`
Version mismatch!

Folder:
${newest.version}

Package:
${pkg.version}
`);

    process.exit(1);

}


console.log(`
Update verified:
restart-cmd@${newest.version}
`);

console.log("Ready for installer.");